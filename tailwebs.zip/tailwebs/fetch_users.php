<?php
include 'database.php'; 

$query = "SELECT u.id, u.username, ug.name AS usergroup, u.usergroup_id 
          FROM users u 
          JOIN usergroups ug ON u.usergroup_id = ug.id";
$result = $conn->query($query);

$output = ''; 

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        $output .= "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['username']}</td>
                        <td>{$row['usergroup']}</td>
                        <td class='actions'>
                            <button class='btn btn-sm btn-warning' data-bs-toggle='modal' data-bs-target='#userModal' onclick='editUser({$row['id']}, \"{$row['username']}\", \"{$row['usergroup_id']}\")'>Edit</button>
                            <button class='btn btn-sm btn-danger' onclick='deleteUser({$row['id']})'>Delete</button>
                        </td>
                    </tr>";
    }
} else {
    $output = "<tr><td colspan='4'>No users found</td></tr>";
}


echo $output;
exit;
?>
