<?php
include 'database.php';

header('Content-Type: application/json');

$query = "SELECT id, name FROM usergroups";
$result = $conn->query($query);

$userGroups = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $userGroups[] = $row;
    }
}

echo json_encode($userGroups);
exit;
?>
