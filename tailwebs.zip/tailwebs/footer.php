<footer class="footer bg-dark text-white py-3">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                Udhaya Teacher Portal App @ <?php echo date("Y")?>
            </div>
            <div>
                By Udhayakumar
            </div>
        </div>
    </div>
</footer>

<style>
    html, body {
        height: 100%;
        margin: 0;
    }
    body {
        display: flex;
        flex-direction: column;
        min-height: 100vh; 
    }
    .footer {
        margin-top: auto;
    }
</style>
