<?php
include 'database.php';

$query = "SELECT * FROM usergroups";
$result = $conn->query($query);

$output = '';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $output .= "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['description']}</td>
                        <td class='actions'>
                            <button class='btn btn-sm btn-warning' data-bs-toggle='modal' data-bs-target='#userGroupModal' onclick='editUserGroup({$row['id']}, \"{$row['name']}\", \"{$row['description']}\")'>Edit</button>
                            <button class='btn btn-sm btn-danger' onclick='deleteUserGroup({$row['id']})'>Delete</button>
                        </td>
                    </tr>";
    }
} else {
    $output = "<tr><td colspan='4'>No user groups found</td></tr>";
}

echo $output;
exit;
?>
