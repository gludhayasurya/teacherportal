<?php
include 'session_check.php';
include 'navbar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Groups Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert -->
        <script src="js/common.js"></script>

         <style>
    th {
        text-align: center; 
    }

    th:first-child {
        text-align: left; 
    }

    .actions {
        display: flex;
        justify-content: center;
        gap: 10px; 
    }
</style>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3>User Management</h3>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#userModal" onclick="resetModal()">Add User</button>
        </div>
        
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>User Group</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>               
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="userForm">
                    <input type="hidden" id="userId" name="user_id">
                    <input type="hidden" id="formAction" name="action">
                    <div class="modal-header">
                        <h5 class="modal-title" id="userModalLabel">Add User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3" id="passwordField">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="userGroup" class="form-label">User Group</label>
                            <select class="form-select" id="userGroup" name="usergroup_id" required>
							    <option value="" disabled selected>Select User Group</option>
							</select>
                        </div>
                    </div>
                     <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="submitForm()">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
function resetModal() {
    document.getElementById('userForm').reset(); // Reset the form
    document.getElementById('userModalLabel').textContent = 'Add User'; // Set modal title
    document.getElementById('passwordField').style.display = 'block'; // Show password field
    document.getElementById('formAction').value = 'add'; // Set form action to 'add'
    
    loadUserGroups(); // Load user groups with no pre-selected value
}

function editUser(id, username, usergroup_id) {
    document.getElementById('userId').value = id; // Set user ID
    document.getElementById('username').value = username; // Set username
    document.getElementById('userModalLabel').textContent = 'Edit User'; // Set modal title
    document.getElementById('passwordField').style.display = 'none'; // Hide password field
    document.getElementById('formAction').value = 'edit'; // Set form action to 'edit'
    
    loadUserGroups(usergroup_id); // Load user groups with the selected value
}



function deleteUser(id) {
    showConfirmDialog('Are you sure?', 'You won\'t be able to revert this!')
        .then((result) => {
            if (result.isConfirmed) {
                // Proceed with deletion
                $.ajax({
                    url: 'add_edit_user.php',
                    type: 'GET',
                    data: { id: id, action: 'delete' },
                    success: function(response) {
                        showAlert('Deleted!', response.message, 'success');
                        loadUsers(); // Reload the table after deletion
                    },
                    error: function() {
                        showAlert('Error!', 'Failed to delete User.', 'error');
                    }
                });
            }
        });
}

function submitForm() {
    var formData = $('#userForm').serialize();

    $.ajax({
        url: 'add_edit_user.php',
        type: 'POST',
        data: formData,
        success: function(response) {
            showAlert('Success!', response.message, 'success');
            $('#userModal').modal('hide');
            loadUsers(); // Reload the table after submission
        },
        error: function() {
            showAlert('Error!', 'Failed to process the request.', 'error');
        }
    });
}

function loadUsers() {
    $.ajax({
        url: 'fetch_users.php',
        type: 'GET',
        success: function(response) {
            $('table tbody').html(response); // Update the table body with new data
        },
        error: function() {
            showAlert('Error!', 'Failed to load Users.', 'error');
        }
    });
}

function loadUserGroups(selectedGroupId = null) {
    $.ajax({
        url: 'select_usergroups.php',
        type: 'GET',
        success: function(response) {
            var userGroups = typeof response === 'string' ? JSON.parse(response) : response;
            var $userGroupSelect = $('#userGroup');
            $userGroupSelect.empty(); // Clear existing options
            $userGroupSelect.append('<option value="" disabled>Select User Group</option>'); // Default option

            $.each(userGroups, function(index, group) {
                var isSelected = selectedGroupId && selectedGroupId == group.id ? 'selected' : '';
                $userGroupSelect.append('<option value="' + group.id + '" ' + isSelected + '>' + group.name + '</option>');
            });

            // Ensure the default "Select User Group" option is selected if not editing
            if (!selectedGroupId) {
                $userGroupSelect.val(''); // Ensure no group is selected
            }
        },
        error: function() {
            showAlert('Error!', 'Failed to load User Groups.', 'error');
        }
    });
}




$(document).ready(function() {
    loadUsers(); // Load the users on page load
});
</script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'footer.php'; ?>

</body>
</html>
