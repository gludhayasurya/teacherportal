// Function to show SweetAlert messages
function showAlert(title, text, icon, confirmButtonText = 'OK') {
    Swal.fire({
        title: title,
        text: text,
        icon: icon,
        confirmButtonText: confirmButtonText
    });
}

// Function to show SweetAlert confirmation dialog
function showConfirmDialog(title, text, confirmButtonText = 'Yes, delete it!', cancelButtonText = 'No, cancel!') {
    return Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: confirmButtonText,
        cancelButtonText: cancelButtonText
    });
}