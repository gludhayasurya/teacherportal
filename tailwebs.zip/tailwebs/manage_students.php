<?php
include 'database.php';
session_start();

$action = $_POST['action'] ?? $_GET['action'] ?? '';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$teacher_id = $_SESSION['user_id']; 

if ($action == 'add') {
    // Add new student record
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $marks = $_POST['marks'];

    // Insert new subject if it doesn't exist and get its ID
    $subject_stmt = $conn->prepare("SELECT id FROM subjects WHERE name = ?");
    $subject_stmt->bind_param('s', $subject);
    $subject_stmt->execute();
    $subject_stmt->store_result();

    if ($subject_stmt->num_rows > 0) {
        $subject_stmt->bind_result($subject_id);
        $subject_stmt->fetch();
    } else {
        $insert_subject_stmt = $conn->prepare("INSERT INTO subjects (name) VALUES (?)");
        $insert_subject_stmt->bind_param('s', $subject);
        $insert_subject_stmt->execute();
        $subject_id = $insert_subject_stmt->insert_id;
        $insert_subject_stmt->close();
    }

    $subject_stmt->close();

    // Insert student record into student_marks table
    $stmt = $conn->prepare("INSERT INTO student_marks (student_name, subject_id, marks, teacher_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('siii', $name, $subject_id, $marks, $teacher_id);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Student added successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to add student.']);
    }

    $stmt->close();

} elseif ($action == 'update') {
    // Update student details
    $id = $_POST['id'];
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $marks = $_POST['marks'];

    // Update subject if it doesn't exist and get its ID
    $subject_stmt = $conn->prepare("SELECT id FROM subjects WHERE name = ?");
    $subject_stmt->bind_param('s', $subject);
    $subject_stmt->execute();
    $subject_stmt->store_result();

    if ($subject_stmt->num_rows > 0) {
        $subject_stmt->bind_result($subject_id);
        $subject_stmt->fetch();
    } else {
        $insert_subject_stmt = $conn->prepare("INSERT INTO subjects (name) VALUES (?)");
        $insert_subject_stmt->bind_param('s', $subject);
        $insert_subject_stmt->execute();
        $subject_id = $insert_subject_stmt->insert_id;
        $insert_subject_stmt->close();
    }

    $subject_stmt->close();

    // Update student record
    $stmt = $conn->prepare("UPDATE student_marks SET student_name = ?, subject_id = ?, marks = ?, teacher_id = ? WHERE id = ?");
    $stmt->bind_param('siiii', $name, $subject_id, $marks, $teacher_id, $id);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Student updated successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update student.']);
    }

    $stmt->close();

} elseif ($action == 'delete') {
    // Delete student record
    $id = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM student_marks WHERE id = ?");
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Student deleted successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to delete student.']);
    }

    $stmt->close();
}

$conn->close();
?>
