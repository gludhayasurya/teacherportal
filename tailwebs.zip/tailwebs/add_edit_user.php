<?php
include 'session_check.php'; 
include 'database.php'; 

header('Content-Type: application/json');

// Handle Add and Edit User
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    $username = $_POST['username'];
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $usergroup_id = $_POST['usergroup_id'];

    //echo $action;exit;

    if ($action == 'add') {
        if (!empty($password)) {
            $password = password_hash($password, PASSWORD_DEFAULT); // Hash password
        }
        $stmt = $conn->prepare("INSERT INTO users (username, password, usergroup_id) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $username, $password, $usergroup_id);

        if ($stmt->execute()) {
            echo json_encode(['message' => 'User added successfully!']);
        } else {
            echo json_encode(['message' => 'Failed to add User.']);
        }

        $stmt->close();
        exit();
    }

    if ($action == 'edit') {
        $user_id = $_POST['user_id'];

        if (!empty($password)) {
            $password = password_hash($password, PASSWORD_DEFAULT); // Hash password if provided
            $stmt = $conn->prepare("UPDATE users SET username = ?, password = ?, usergroup_id = ? WHERE id = ?");
            $stmt->bind_param("ssii", $username, $password, $usergroup_id, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = ?, usergroup_id = ? WHERE id = ?");
            $stmt->bind_param("sii", $username, $usergroup_id, $user_id);
        }

        if ($stmt->execute()) {
            echo json_encode(['message' => 'User updated successfully!']);
        } else {
            echo json_encode(['message' => 'Failed to update User.']);
        }

        $stmt->close();
        exit();
    }
}

// Handle Delete User
if (isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'delete') {
    $user_id = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    if ($stmt === false) {
        echo json_encode(['message' => 'Prepare failed: ' . $conn->error]);
        exit();
    }

    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        echo json_encode(['message' => 'User deleted successfully!']);
    } else {
        echo json_encode(['message' => 'Failed to delete User: ' . $stmt->error]);
    }

    $stmt->close();
    exit();
}
?>
