<?php
include 'session_check.php'; 
include 'database.php'; 

header('Content-Type: application/json');

// Handle Add, Edit, and Delete User Group
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    $usergroup_name = $_POST['usergroup_name'];
    $usergroup_description = isset($_POST['usergroup_description']) ? $_POST['usergroup_description'] : '';

    if ($action == 'add') {
        $stmt = $conn->prepare("INSERT INTO usergroups (name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $usergroup_name, $usergroup_description);

        if ($stmt->execute()) {
            echo json_encode(['message' => 'User Group added successfully!']);
        } else {
            echo json_encode(['message' => 'Failed to add User Group.']);
        }

        $stmt->close();
        exit();
    }

    if ($action == 'edit') {
        $usergroup_id = $_POST['usergroup_id'];

        $stmt = $conn->prepare("UPDATE usergroups SET name = ?, description = ? WHERE id = ?");
        $stmt->bind_param("ssi", $usergroup_name, $usergroup_description, $usergroup_id);

        if ($stmt->execute()) {
            echo json_encode(['message' => 'User Group updated successfully!']);
        } else {
            echo json_encode(['message' => 'Failed to update User Group.']);
        }

        $stmt->close();
        exit();
    }
}


// Handle Delete User Group
if (isset($_GET['id']) && isset($_GET['action']) && $_GET['action'] == 'delete') {
    $usergroup_id = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM usergroups WHERE id = ?");
if ($stmt === false) {
    echo json_encode(['message' => 'Prepare failed: ' . $conn->error]);
    exit();
}

$stmt->bind_param("i", $usergroup_id);

if ($stmt->execute()) {
    echo json_encode(['message' => 'User Group deleted successfully!']);
} else {
    echo json_encode(['message' => 'Failed to delete User Groupddddddd: ' . $stmt->error]);
}


    $stmt->close();
    exit();
}
?>
