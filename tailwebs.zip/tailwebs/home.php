<?php
include 'session_check.php';
include 'navbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Groups Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert -->
    <script src="js/common.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome -->

    <style>
        .hero-section {
            background-color: #007bff;
            color: #ffffff;
            padding: 40px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 1.75rem;
            margin-bottom: 10px;
        }
        .hero-section p {
            font-size: 1rem;
        }
        .containerhome {
            padding: 15px;
        }
        .top-bar {
            background-color: #dc3545; 
            color: #ffffff; 
            padding: 20px;
        }
        .top-bar .left-side {
            float: left;
            font-size: 1.5rem; /* Increased text size */
        }
        .top-bar .right-side {
            float: right;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            max-width: 300px; /* Ensure the right-side content does not exceed a certain width */
        }
        .top-bar .right-side i {
            margin-right: 8px; /* Space between icon and text */
        }
        .address-line {
            white-space: normal; /* Allow text to wrap */
            margin-bottom: 4px; /* Space between lines */
        }
    </style>
</head>
<body class="bg-light">

    <div class="top-bar">
        <div class="container">
            <div class="left-side">
                <span class="text-white">tailwebs.</span>
            </div>
            <div class="right-side">
                <div class="address-line">
                    <i class="fas fa-map-marker-alt"></i> <!-- Map icon -->

                    <span class="text-white">208, Amarjyoti Layout,</span>
                </div>
                <div class="address-line">
                    <span class="text-white">Domlur, Bengaluru, Karnataka 560071</span>
                </div>
            </div>
        </div>
    </div>

    <header class="hero-section">
        <div class="containerhome">
            <h1>Welcome to the Teacher Portal</h1>
            <p>Manage student marks and more with ease.</p>
        </div>
    </header>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'footer.php'; ?>
</body>
</html>
