<?php
include 'session_check.php'; 
include 'navbar.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Groups Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert -->
        <script src="js/common.js"></script>

    <style>
    th {
        text-align: center; 
    }

    th:first-child {
        text-align: left; 
    }

    .actions {
        display: flex;
        justify-content: center;
        gap: 10px; 
    }
</style>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3>User Groups Management</h3>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#userGroupModal" onclick="resetModal()">Add User Group</button>
        </div>
        
        <table class="table table-bordered table-striped" id="userGroupsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User Group Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="userGroupModal" tabindex="-1" aria-labelledby="userGroupModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="userGroupForm">
                    <input type="hidden" id="userGroupId" name="usergroup_id">
                    <input type="hidden" id="formAction" name="action"> <!-- Hidden input for action -->
                    <div class="modal-header">
                        <h5 class="modal-title" id="userGroupModalLabel">Add User Group</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="userGroupName" class="form-label">User Group Name</label>
                            <input type="text" class="form-control" id="userGroupName" name="usergroup_name" required>
                        </div>
                         <div class="mb-3">
                            <label for="userGroupDescription" class="form-label">Description</label>
                            <textarea class="form-control" id="userGroupDescription" name="usergroup_description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="submitForm()">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>

        function resetModal() {
            document.getElementById('userGroupForm').reset();
            document.getElementById('userGroupModalLabel').textContent = 'Add User Group';
            document.getElementById('formAction').value = 'add'; // Set action to 'add'
        }

        function editUserGroup(id, name, description) {
            document.getElementById('userGroupId').value = id;
            document.getElementById('userGroupName').value = name;
            document.getElementById('userGroupDescription').value = description;
            document.getElementById('userGroupModalLabel').textContent = 'Edit User Group';
            document.getElementById('formAction').value = 'edit'; // Set action to 'edit'
        }

        function deleteUserGroup(id) {
            showConfirmDialog('Are you sure?', 'You won\'t be able to revert this!')
                .then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'add_edit_usergroup.php',
                            type: 'GET',
                            data: { id: id, action: 'delete' },
                            success: function(response) {
                                showAlert('Deleted!', response.message, 'success');
                                loadUserGroups(); // Reload the table after deletion
                            },
                            error: function() {
                                showAlert('Error!', 'Failed to delete User Group.', 'error');
                            }
                        });
                    }
                });
        }


        function submitForm() {
            var formData = $('#userGroupForm').serialize();

            $.ajax({
                url: 'add_edit_usergroup.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    showAlert('Success!', response.message, 'success');
                    $('#userGroupModal').modal('hide');
                    loadUserGroups(); // Reload the table after submission
                },
                error: function() {
                    showAlert('Error!', 'Failed to process the request.', 'error');
                }
            });
        }

        function loadUserGroups() {
            $.ajax({
                url: 'fetch_usergroups.php',
                type: 'GET',
                success: function(response) {
                    $('#userGroupsTable tbody').html(response); // Update the table body with new data
                },
                error: function() {
                    showAlert('Error!', 'Failed to load User Groups.', 'error');
                }
            });
        }

        $(document).ready(function() {
            loadUserGroups(); // Load the user groups on page load
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'footer.php'; ?>
</body>
</html>
