<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"> <!-- Font Awesome -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Center the form on the page */
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
        }

        .login-container {
            background-color: #fff;
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            width: 100%;
        }

        .login-container h1 {
            text-align: center;
            margin-bottom: 40px;
            font-weight: bold;
            font-size: 28px;
            color: #dc3545;
        }

        .form-control {
            height: 50px;
            font-size: 18px;
            padding: 10px;
            border: none;
            border-radius: 0 5px 5px 0;
        }

        .input-group {
            border: 1px solid #ced4da;
            border-radius: 5px;
            overflow: hidden;
        }

        .input-group-text {
            background-color: #fff;
            border: none;
            border-right: 1px solid #ced4da;
            border-radius: 5px 0 0 5px;
            padding: 0 15px;
        }

        .form-control.is-invalid {
            border-color: #dc3545;
            box-shadow: none;
        }

        .input-group-text.is-invalid {
            border-color: #dc3545;
        }

        .btn-login {
            background-color: #333;
            color: white;
            padding: 12px;
            font-size: 18px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn-login:hover {
            background-color: #444;
        }

        .forgot-password {
            display: block;
            text-align: right;
            margin-top: 10px;
            font-size: 14px;
            color: #007bff;
            text-decoration: none;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }

        .input-group-text i {
            font-size: 20px;
            margin: 0;
            padding: 0;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h1>tailwebs.</h1>
        <form id="loginForm">
            <div class="mb-4">
                <div class="input-group">
                    <span class="input-group-text"><i class="fa fa-user"></i></span>
                    <input type="text" class="form-control" id="username" placeholder="Username" name="username">
                </div>
                <div class="invalid-feedback" id="usernameError">Please enter your username.</div>
            </div>
            <div class="mb-4">
                <div class="input-group">
                    <span class="input-group-text"><i class="fa fa-lock"></i></span>
                    <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                    <span class="input-group-text"><i class="fa fa-eye"></i></span>
                </div>
                <div class="invalid-feedback" id="passwordError">Please enter your password.</div>
            </div>
            <a href="#" class="forgot-password">Forgot Password?</a>
            <div class="d-grid mt-4">
                <button type="submit" class="btn btn-login">Login</button>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script> <!-- Font Awesome -->
<script>
    $(document).ready(function() {
        // Toggle password visibility
        $('.input-group-text').on('click', function() {
            let passwordField = $(this).siblings('input');
            let type = passwordField.attr('type') === 'password' ? 'text' : 'password';
            passwordField.attr('type', type);

            // Toggle the icon
            $(this).find('i').toggleClass('fa-eye fa-eye-slash');
        });

        // Hide error and red border on typing
        $('#username, #password').on('input', function() {
            $(this).removeClass('is-invalid'); // Remove red border
            $(this).siblings('.input-group-text').removeClass('is-invalid'); // Remove red border from icon
            $(this).siblings('.invalid-feedback').hide(); // Hide error message
        });

        $('#loginForm').on('submit', function(event) {
            event.preventDefault();

            // Reset validation errors
            $('.invalid-feedback').hide();
            $('.form-control').removeClass('is-invalid');
            $('.input-group-text').removeClass('is-invalid');

            let isValid = true;

            if ($('#username').val().trim() === '') {
                $('#usernameError').show();
                $('#username').addClass('is-invalid');
                $('#username').siblings('.input-group-text').addClass('is-invalid');
                isValid = false;
            }

            if ($('#password').val().trim() === '') {
                $('#passwordError').show();
                $('#password').addClass('is-invalid');
                $('#password').siblings('.input-group-text').addClass('is-invalid');
                isValid = false;
            }

            if (isValid) {
                $.ajax({
                    url: 'login_check.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    success: function(response) {
                        if (response.success) {
                            window.location.href = 'student_marks.php';
                        } else {
                            Swal.fire({
                                toast: true,
                                position: 'top-end',
                                icon: 'error',
                                title: 'Invalid Credentials',
                                showConfirmButton: false,
                                timer: 3000,
                            });
                        }
                    }
                });
            }
        });
    });
</script>

</body>

</html>
