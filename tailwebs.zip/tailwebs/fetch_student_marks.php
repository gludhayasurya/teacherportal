<?php
include 'database.php';

// Fetch student records with subject names
$query = "SELECT
            sm.id,
            sm.student_name,
            s.name,
            sm.marks
          FROM
            student_marks sm
          JOIN
            subjects s ON sm.subject_id = s.id";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Extract the first letter of the student name
        $avatarLetter = strtoupper(substr($row['student_name'], 0, 1));
        $studentName = htmlspecialchars($row['student_name']);
        $subjectName = htmlspecialchars($row['name']);
        $marks = htmlspecialchars($row['marks']);

        echo '<tr data-id="' . $row['id'] . '">
                <td>
                    <div class="avatar-name-container">
                        <!-- Avatar -->
                        <div class="avatar">
                            ' . $avatarLetter . '
                        </div>
                        <span class="text-value">' . $studentName . '</span>
                    </div>
                    <input type="text" class="form-control edit-input student-name d-none" value="' . $studentName . '">
                </td>
                <td>
                    <span class="text-value">' . $subjectName . '</span>
                    <input type="text" class="form-control edit-input student-subject d-none" value="' . $subjectName . '">
                </td>
                <td class="text-center">
                    <span class="text-value">' . $marks . '</span>
                    <input type="number" class="form-control edit-input student-marks d-none" value="' . $marks . '">
                </td>
                <td class="actions text-center">
                    <button class="btn btn-primary btn-sm edit-btn">Edit</button>
                    <button class="btn btn-success btn-sm save-btn d-none">Update</button>
                    <button class="btn btn-danger btn-sm delete-btn">Delete</button>
                </td>
            </tr>';
    }
} else {
    echo '<tr><td class="text-center" colspan="5">No students found</td></tr>';
}

$conn->close();
?>
