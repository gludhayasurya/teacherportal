<?php
include 'session_check.php'; 
include 'navbar.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Portal - Student Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert -->
    <script src="js/common.js"></script>

    <style>
        .modal-dialog {
            max-width: 500px; 
        }

        .modal-content {
            border-radius: 10px;
            padding: 20px;
            background-color: #f7f7f7; 
            border: none;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            border-bottom: none;
            padding-bottom: 0;
        }

        .modal-title {
            font-weight: bold;
            color: #333;
        }

        .modal-body {
            padding-top: 10px;
        }

        .form-group {
            margin-bottom: 1rem; 
        }

        .form-control {
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 10px;
            box-shadow: none;
            font-size: 14px;
        }

        .form-control:focus {
            border-color: #333; 
            box-shadow: none;
        }

        .modal-footer {
            border-top: none;
            padding-top: 10px;
        }

        .btn-primary {
            background-color: #333; 
            border-color: #333;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 14px;
        }

        .btn-primary:hover {
            background-color: #555; 
            border-color: #555;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: 500;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
        }

        /* Table styling */
        .table {
            border-collapse: collapse;
        }

        .table th {
            border: 1px solid #ddd; 
        }

        .table th:first-child {
            border-left: none; 
        }

        .table th:last-child {
            border-right: none; 
        }

        .table td {
            border: none; 
        }

        .table tr {
            border-bottom: 1px solid #ddd; 
        }

        .table td, .table th {
            padding: 10px; 
        }

        .text-center {
            text-align: center;
        }
        .table .actions {
            display: flex; 
            justify-content: center; 
            gap: 10px; 
        }

        .table .actions .btn {
            margin: 0; 
        }
        .avatar-name-container {
            display: flex;
            align-items: center;
        }

        .avatar {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: #1fa6dd;
            color: white;
            font-weight: bold;
            margin-right: 30px;
            margin-left: 10px;
            text-align: center;
            line-height: 1;

        }

        .text-value {
            line-height: 40px;
        }

    </style>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3>Student Management</h3>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#studentModal" onclick="resetModal()">Add Student</button>
        </div>
        
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Subject</th>
                    <th class="text-center">Marks</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="studentModal" tabindex="-1" aria-labelledby="studentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form id="studentForm">
                    <input type="hidden" id="studentId" name="student_id">
                    <input type="hidden" id="formAction" name="action">
                    <div class="modal-header">
                        <h5 class="modal-title" id="studentModalLabel">Add Student</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="studentName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="studentName" name="name">
                            <div class="invalid-feedback">Please enter a student name.</div>
                        </div>
                        <div class="form-group">
                            <label for="studentSubject" class="form-label">Subject</label>
                            <input type="text" class="form-control" id="studentSubject" name="subject">
                            <div class="invalid-feedback">Please enter a subject.</div>
                        </div>
                        <div class="form-group">
                            <label for="studentMarks" class="form-label">Marks</label>
                            <input type="number" class="form-control" id="studentMarks" name="marks">
                            <div class="invalid-feedback">Please enter valid marks.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="validateAndSubmit()">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function resetModal() {
            document.getElementById('studentForm').reset(); // Reset the form
            document.getElementById('studentModalLabel').textContent = 'Add Student'; // Set modal title
            document.getElementById('formAction').value = 'add'; // Set form action to 'add'
        }

        function editStudent(id, name, subject, marks) {
            document.getElementById('studentId').value = id; // Set student ID
            document.getElementById('studentName').value = name; // Set student name
            document.getElementById('studentSubject').value = subject; // Set student subject
            document.getElementById('studentMarks').value = marks; // Set student marks
            document.getElementById('studentModalLabel').textContent = 'Edit Student'; // Set modal title
            document.getElementById('formAction').value = 'edit'; // Set form action to 'edit'
        }

        // Validate and submit the form
        function validateAndSubmit() {
            let isValid = true;

            $('#studentForm .form-control').each(function() {
                if ($(this).val().trim() === '') {
                    $(this).addClass('is-invalid');
                    isValid = false;
                } else {
                    $(this).removeClass('is-invalid');
                }
            });

            if (isValid) {
                submitForm(); // Call the existing submitForm function if validation passes
            }
        }
        
        function submitForm() {
            var formData = $('#studentForm').serialize();

            $.ajax({
                url: 'manage_students.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    showAlert('Success!', response.message, 'success');
                    $('#studentModal').modal('hide');
                    loadStudents(); // Reload the table after submission
                },
                error: function() {
                    showAlert('Error!', 'Failed to process the request.', 'error');
                }
            });
        }

        function loadStudents() {
            $.ajax({
                url: 'fetch_student_marks.php',
                type: 'GET',
                success: function(response) {
                    $('table tbody').html(response); // Update the table body with new data
                },
                error: function() {
                    showAlert('Error!', 'Failed to load Students.', 'error');
                }
            });
        }

        $(document).ready(function() {
            loadStudents(); // Load the students on page load

            // Edit button click event
            $('table tbody').on('click', '.edit-btn', function() {
                var $row = $(this).closest('tr');
                
                $row.find('input').removeClass('d-none').prop('disabled', false); // Show input fields
                $row.find('.edit-btn').hide(); // Hide edit button
                $row.find('.save-btn').removeClass('d-none'); // Show save button

                var id = $row.data('id');
                var name = $row.find('.student-name').text();
                var subject = $row.find('.student-subject').text();
                var marks = $row.find('.student-marks').text();

                // Set values in the modal
                editStudent(id, name, subject, marks);
            });

            // Save button click event
            $('table tbody').on('click', '.save-btn', function() {
                var $row = $(this).closest('tr');
                var id = $row.data('id');
                var name = $row.find('.student-name').val();
                var subject = $row.find('.student-subject').val();
                var marks = $row.find('.student-marks').val();

                $.ajax({
                    url: 'manage_students.php',
                    type: 'POST',
                    data: {
                        action: 'update',
                        id: id,
                        name: name,
                        subject: subject,
                        marks: marks
                    },
                    success: function(response) {
                        var res = JSON.parse(response);
                        if (res.status === 'success') {
                            showAlert('Updated!', res.message, 'success');
                            loadStudents(); // Reload the table after successful update

                            // Hide input fields and show the edit button
                            $row.find('input').addClass('d-none').prop('disabled', true);
                            $row.find('.edit-btn').show();
                            $row.find('.save-btn').addClass('d-none');
                        } else {
                            showAlert('Error!', res.message, 'error');
                        }
                    },
                    error: function() {
                        showAlert('Error!', 'Failed to update student details.', 'error');
                    }
                });
            });

            // Delete button click event
            $('table tbody').on('click', '.delete-btn', function() {
                var $row = $(this).closest('tr');
                var id = $row.data('id');

                showConfirmDialog(
                    'Are you sure?',
                    "You won't be able to revert this!",
                    'Yes, delete it!',
                    'No, cancel!'
                ).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'manage_students.php',
                            type: 'GET',
                            data: { id: id, action: 'delete' },
                            success: function(response) {
                                var res = JSON.parse(response);
                                if (res.status === 'success') {
                                    showAlert('Deleted!', res.message, 'success');
                                    $row.remove(); // Remove the row from the table
                                } else {
                                    showAlert('Error!', res.message, 'error');
                                }
                            },
                            error: function() {
                                showAlert('Error!', 'Failed to delete student.', 'error');
                            }
                        });
                    }
                });
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'footer.php'; ?>
</body>
</html>
