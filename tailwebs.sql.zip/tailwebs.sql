-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 14, 2024 at 08:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tailwebs`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_marks`
--

CREATE TABLE `student_marks` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `marks` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_marks`
--

INSERT INTO `student_marks` (`id`, `student_name`, `subject_id`, `marks`, `teacher_id`, `created_at`, `updated_at`) VALUES
(2, 'Udhayakumar', 11, 23478, 1, '2024-08-13 17:43:22', '2024-08-13 17:49:30'),
(4, 'surya', 12, 555, 1, '2024-08-13 18:01:26', '2024-08-13 18:01:26'),
(5, 'Mohan', 13, 10034, 1, '2024-08-13 18:05:29', '2024-08-13 19:19:07'),
(10, 'Tailwebs.', 17, 6500, 1, '2024-08-14 06:24:03', '2024-08-14 06:37:09');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Maths', '2024-08-13 16:56:22', '2024-08-13 16:56:22'),
(2, 'Maths123', '2024-08-13 16:57:22', '2024-08-13 16:57:22'),
(3, 'Maths12356', '2024-08-13 16:59:48', '2024-08-13 16:59:48'),
(4, 'eng', '2024-08-13 17:02:38', '2024-08-13 17:02:38'),
(5, 'Tam', '2024-08-13 17:05:30', '2024-08-13 17:05:30'),
(6, 'Tamil', '2024-08-13 17:38:38', '2024-08-13 17:38:38'),
(7, 'english', '2024-08-13 17:43:32', '2024-08-13 17:43:32'),
(8, 'sci', '2024-08-13 17:45:02', '2024-08-13 17:45:02'),
(9, 'mat', '2024-08-13 17:46:20', '2024-08-13 17:46:20'),
(10, 'Soc', '2024-08-13 17:49:00', '2024-08-13 17:49:00'),
(11, 'Tamqaqa', '2024-08-13 17:49:30', '2024-08-13 17:49:30'),
(12, 'engl', '2024-08-13 18:01:26', '2024-08-13 18:01:26'),
(13, 'MAth', '2024-08-13 18:05:29', '2024-08-13 18:05:29'),
(14, 'Social', '2024-08-13 19:14:30', '2024-08-13 19:14:30'),
(15, '', '2024-08-14 06:05:29', '2024-08-14 06:05:29'),
(16, 'IT', '2024-08-14 06:24:03', '2024-08-14 06:24:03'),
(17, 'IT Industry', '2024-08-14 06:24:23', '2024-08-14 06:24:23');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `usergroups`
--

CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usergroups`
--

INSERT INTO `usergroups` (`id`, `name`, `description`) VALUES
(1, 'superadmin', 'Has full access to all functionalities'),
(2, 'admin', 'Can manage users and students, but with limited access compared to superadmin'),
(3, 'teacher', 'Can manage their own student listings and view data');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usergroup_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `usergroup_id`, `created_at`, `updated_at`) VALUES
(1, 'superadmin', '$2y$10$kher4EoJNNwnZFaFLFeNbuu0Qeewwi6YOcF9PSSXjUMDEgpG9woRi', 1, '2024-08-12 11:28:21', '2024-08-12 12:04:49'),
(2, 'admin_user', '<hashed_password>', 2, '2024-08-12 11:28:21', '2024-08-12 11:28:21'),
(5, 'qwqwq', '$2y$10$uB0jnr/Fku7itThl5f5HyeGzLTfjXHHOqRCB0Pat7rJJ/5BLW32QS', 1, '2024-08-13 03:01:10', '2024-08-13 03:01:25'),
(6, 'wwwpp', '$2y$10$Axvya/T8MEGB/XTHfNFBMOlOOEiM46U00SxcRQ34zQgKz748AEFOW', 2, '2024-08-13 03:10:34', '2024-08-13 03:10:49'),
(9, 'Tailwebs user', '$2y$10$8Fexo7114sjZxhm26ZItT.VLa8sH8mxqI09DcQDIHBqdlwV1Oyexa', 1, '2024-08-14 06:24:56', '2024-08-14 06:24:56'),
(10, 'Tail2 edit', '$2y$10$DKFI4pfxnSLJxO5SFGB53uV99Sb7f5h6CZr1HZ0SDrsgommT3GPou', 3, '2024-08-14 06:25:11', '2024-08-14 06:25:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_marks`
--
ALTER TABLE `student_marks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `usergroups`
--
ALTER TABLE `usergroups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `usergroup_id` (`usergroup_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_marks`
--
ALTER TABLE `student_marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usergroups`
--
ALTER TABLE `usergroups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student_marks`
--
ALTER TABLE `student_marks`
  ADD CONSTRAINT `student_marks_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  ADD CONSTRAINT `student_marks_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`usergroup_id`) REFERENCES `usergroups` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
